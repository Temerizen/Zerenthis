
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'

import Core from './pages/Core'
import Cognitive from './pages/Cognitive'
import Learning from './pages/Learning'
import Execution from './pages/Execution'
import Creation from './pages/Creation'
import Simulation from './pages/Simulation'
import Founder from './pages/Founder'

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Core />} />
          <Route path="/cognitive" element={<Cognitive />} />
          <Route path="/learning" element={<Learning />} />
          <Route path="/execution" element={<Execution />} />
          <Route path="/creation" element={<Creation />} />
          <Route path="/simulation" element={<Simulation />} />
          <Route path="/founder" element={<Founder />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}
