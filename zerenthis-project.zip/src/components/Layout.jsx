
import Sidebar from './Sidebar'

export default function Layout({ children }) {
  return (
    <div style={{display:'flex'}}>
      <Sidebar />
      <div style={{flex:1,padding:30,color:'#EDEDED'}}>
        {children}
      </div>
    </div>
  )
}
