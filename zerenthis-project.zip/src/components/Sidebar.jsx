
import { NavLink } from 'react-router-dom'

const nav = [
  ['/', 'Core'],
  ['/cognitive', 'Cognitive Lab'],
  ['/learning', 'AI School'],
  ['/execution', 'Execution'],
  ['/creation', 'Content Factory'],
  ['/simulation', 'Simulation'],
  ['/founder', 'Founder Panel']
]

export default function Sidebar() {
  return (
    <div style={{
      width: 220,
      background: '#0A0A0F',
      color: '#EDEDED',
      height: '100vh',
      padding: 20,
      borderRight: '1px solid #1a1a1f'
    }}>
      <div style={{marginBottom:30}}>
        <div style={{fontSize:28,fontWeight:'bold'}}>Z</div>
        <div>Zerenthis</div>
        <div style={{opacity:0.6,fontSize:12}}>Ascension Engine</div>
      </div>

      {nav.map(([path,label]) => (
        <div key={path} style={{marginBottom:10}}>
          <NavLink to={path} style={{color:'#ccc',textDecoration:'none'}}>
            {label}
          </NavLink>
        </div>
      ))}
    </div>
  )
}
