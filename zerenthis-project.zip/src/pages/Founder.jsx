
export default function FounderPanel() {
  return (
    <div>
      <h1>FounderPanel</h1>
      <p>This is the FounderPanel module of Zerenthis.</p>
    </div>
  )
}
