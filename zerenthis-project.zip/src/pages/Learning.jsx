
export default function AISchool() {
  return (
    <div>
      <h1>AISchool</h1>
      <p>This is the AISchool module of Zerenthis.</p>
    </div>
  )
}
