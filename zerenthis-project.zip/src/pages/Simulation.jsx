
export default function Simulation() {
  return (
    <div>
      <h1>Simulation</h1>
      <p>This is the Simulation module of Zerenthis.</p>
    </div>
  )
}
