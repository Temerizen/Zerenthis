
export default function ContentFactory() {
  return (
    <div>
      <h1>ContentFactory</h1>
      <p>This is the ContentFactory module of Zerenthis.</p>
    </div>
  )
}
