
export default function Core() {
  return (
    <div>
      <h1>Core</h1>
      <p>This is the Core module of Zerenthis.</p>
    </div>
  )
}
