
export const BRAND = {
  name: "Zerenthis",
  tagline: "Where Intelligence Becomes Power",
  theme: {
    bg: "#0A0A0F",
    primary: "#7B3FE4",
    accent: "#00D4FF",
    text: "#EDEDED"
  }
}
